package com.sicnu.service;

import com.sicnu.util.Result;

public interface CountService {
    Result countAll();
    Result countCheck();
}
