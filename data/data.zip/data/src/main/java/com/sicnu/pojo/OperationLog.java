package com.sicnu.pojo;


public class OperationLog {

  private Integer ol_id;
  private String ol_type;
  private String ol_level;
  private String ol_location;
  private String ol_time;
  private String ol_message;
  private Integer ol_uid;
  private String ol_uname;
  private String ol_ip;

  public Integer getOl_id() {
    return ol_id;
  }

  public void setOl_id(Integer ol_id) {
    this.ol_id = ol_id;
  }

  public String getOl_type() {
    return ol_type;
  }

  public void setOl_type(String ol_type) {
    this.ol_type = ol_type;
  }

  public String getOl_level() {
    return ol_level;
  }

  public void setOl_level(String ol_level) {
    this.ol_level = ol_level;
  }

  public String getOl_location() {
    return ol_location;
  }

  public void setOl_location(String ol_location) {
    this.ol_location = ol_location;
  }

  public String getOl_time() {
    return ol_time;
  }

  public void setOl_time(String ol_time) {
    this.ol_time = ol_time;
  }

  public String getOl_message() {
    return ol_message;
  }

  public void setOl_message(String ol_message) {
    this.ol_message = ol_message;
  }

  public Integer getOl_uid() {
    return ol_uid;
  }

  public void setOl_uid(Integer ol_uid) {
    this.ol_uid = ol_uid;
  }

  public String getOl_uname() {
    return ol_uname;
  }

  public void setOl_uname(String ol_uname) {
    this.ol_uname = ol_uname;
  }

  public String getOl_ip() {
    return ol_ip;
  }

  public void setOl_ip(String ol_ip) {
    this.ol_ip = ol_ip;
  }
}
