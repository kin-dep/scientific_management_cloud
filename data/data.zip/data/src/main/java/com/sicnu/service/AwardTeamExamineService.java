package com.sicnu.service;

import com.sicnu.util.Result;

public interface AwardTeamExamineService {
    Result selectAwardTeamExamineUser(Integer ae_id);

}
