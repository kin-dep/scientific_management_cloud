package com.sicnu.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PeriodicalPaper {

  private Integer paper_id;
  private Integer periodical_id;


  public Integer getPaper_id() {
    return paper_id;
  }

  public void setPaper_id(Integer paper_id) {
    this.paper_id = paper_id;
  }

  public Integer getPeriodical_id() {
    return periodical_id;
  }

  public void setPeriodical_id(Integer periodical_id) {
    this.periodical_id = periodical_id;
  }
}
