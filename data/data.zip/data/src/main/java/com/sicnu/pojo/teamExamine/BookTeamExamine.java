package com.sicnu.pojo.teamExamine;


public class BookTeamExamine {

  private Integer book_id;
  private Integer user_id;
  private Integer contribution;

  public Integer getContribution() {
    return contribution;
  }

  public void setContribution(Integer contribution) {
    this.contribution = contribution;
  }



  public Integer getBook_id() {
    return book_id;
  }

  public void setBook_id(Integer book_id) {
    this.book_id = book_id;
  }

  public Integer getUser_id() {
    return user_id;
  }

  public void setUser_id(Integer user_id) {
    this.user_id = user_id;
  }



}

