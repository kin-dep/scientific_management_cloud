package com.sicnu.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 获奖级别
 */
@JsonIgnoreProperties(ignoreUnknown = true)public class AwardRank {
    private Integer ar_id;
    private String ar_name;
    private Integer ar_score;

    public Integer getAr_score() {
        return ar_score;
    }

    public void setAr_score(Integer ar_score) {
        this.ar_score = ar_score;
    }

    public Integer getAr_id() {
        return ar_id;
    }

    public void setAr_id(Integer ar_id) {
        this.ar_id = ar_id;
    }

    public String getAr_name() {
        return ar_name;
    }

    public void setAr_name(String ar_name) {
        this.ar_name = ar_name;
    }


}
