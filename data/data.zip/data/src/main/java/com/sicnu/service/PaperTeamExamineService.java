package com.sicnu.service;

import com.sicnu.util.Result;


public interface PaperTeamExamineService {
    Result selectPaperTeamExamineUser(Integer pe_id);

}
