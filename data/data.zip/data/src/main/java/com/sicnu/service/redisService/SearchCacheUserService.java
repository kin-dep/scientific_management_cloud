package com.sicnu.service.redisService;

import java.util.List;

public interface SearchCacheUserService {
    public List searchCacheUser();
}
