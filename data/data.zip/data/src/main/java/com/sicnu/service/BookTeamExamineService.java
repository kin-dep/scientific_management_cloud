package com.sicnu.service;


import com.sicnu.util.Result;

public interface BookTeamExamineService {
    Result selectBookTeamExamineUser(Integer be_id);

}
