package com.sicnu.pojo;


public class PeriodicalPaperExamine {

  private Integer pe_id;
  private Integer periodical_id;


  public Integer getPe_id() {
    return pe_id;
  }

  public void setPe_id(Integer pe_id) {
    this.pe_id = pe_id;
  }

  public Integer getPeriodical_id() {
    return periodical_id;
  }

  public void setPeriodical_id(Integer periodical_id) {
    this.periodical_id = periodical_id;
  }
}
