package com.sicnu.service;

import com.sicnu.util.Result;

public interface PatentTeamExamineService {
    Result selectPatentTeamExamineUser(Integer pe_id);

}
