package com.sicnu.pojo;

/**
 * 专利状态
 */
public class PatentStatus {
    private Integer ps_id;
    private String ps_name;

    public Integer getPs_id() {
        return ps_id;
    }

    public void setPs_id(Integer ps_id) {
        this.ps_id = ps_id;
    }

    public String getPs_name() {
        return ps_name;
    }

    public void setPs_name(String ps_name) {
        this.ps_name = ps_name;
    }
}
