package com.sicnu.pojo.teamMap;

public class UserAuth {
    private String auth_resource;

    public String getAuth_resource() {
        return auth_resource;
    }

    public void setAuth_resource(String auth_resource) {
        this.auth_resource = auth_resource;
    }
}
