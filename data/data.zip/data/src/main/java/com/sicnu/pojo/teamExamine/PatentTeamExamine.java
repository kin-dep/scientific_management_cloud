package com.sicnu.pojo.teamExamine;


public class PatentTeamExamine {

  private Integer patent_id;
  private Integer user_id;
  private Integer contribution;

  public Integer getContribution() {
    return contribution;
  }

  public void setContribution(Integer contribution) {
    this.contribution = contribution;
  }



  public Integer getPatent_id() {
    return patent_id;
  }

  public void setPatent_id(Integer patent_id) {
    this.patent_id = patent_id;
  }

  public Integer getUser_id() {
    return user_id;
  }

  public void setUser_id(Integer user_id) {
    this.user_id = user_id;
  }

}