package com.sicnu.service;

import com.sicnu.util.Result;

public interface ProjectTeamExamineService {

    Result selectProjectTeamExamineUser(Integer pe_id);
}
