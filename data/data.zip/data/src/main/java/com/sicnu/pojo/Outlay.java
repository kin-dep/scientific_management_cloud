package com.sicnu.pojo;


public class Outlay {

  private Integer outlay_id;
  private Integer outlay_start;
  private Integer outlay_end;
  private Integer outlay_score;

  public Integer getOutlay_id() {
    return outlay_id;
  }

  public void setOutlay_id(Integer outlay_id) {
    this.outlay_id = outlay_id;
  }

  public Integer getOutlay_start() {
    return outlay_start;
  }

  public void setOutlay_start(Integer outlay_start) {
    this.outlay_start = outlay_start;
  }

  public Integer getOutlay_end() {
    return outlay_end;
  }

  public void setOutlay_end(Integer outlay_end) {
    this.outlay_end = outlay_end;
  }

  public Integer getOutlay_score() {
    return outlay_score;
  }

  public void setOutlay_score(Integer outlay_score) {
    this.outlay_score = outlay_score;
  }
}
